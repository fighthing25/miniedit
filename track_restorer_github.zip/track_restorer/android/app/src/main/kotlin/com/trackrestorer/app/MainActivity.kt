package com.trackrestorer.app

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
